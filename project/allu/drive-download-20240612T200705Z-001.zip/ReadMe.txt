Admin Login

Admin Admin

Problem solver login:

Washroom 1234
Drinking 1234
Electrical 1234
Light 1234
Projector 1234
Fan 1234
Sanitary 1234
Faculty 1234


id - auto
Type - Washroom
query - comment

Login:

    Type:Login
    Queries 


Problem add Type and comment. send

